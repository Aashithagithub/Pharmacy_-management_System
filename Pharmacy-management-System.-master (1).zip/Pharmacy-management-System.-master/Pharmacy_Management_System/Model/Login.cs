﻿namespace Pharmacy_Management_System.Model
{
    public class Login
    {
        public string EmailID { get; set; }
        public string Password { get; set; }
    }
}
