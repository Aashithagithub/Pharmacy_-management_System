﻿namespace Pharmacy_Management_System.Model
{
    public class Admin
    {
        public string AdminName { get; set; }
        public string Contact { get; set; }
        public string EmailId { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
    }
}
