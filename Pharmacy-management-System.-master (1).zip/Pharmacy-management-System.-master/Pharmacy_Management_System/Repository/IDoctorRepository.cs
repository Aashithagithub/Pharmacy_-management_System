﻿using Pharmacy_Management_System.Model;

namespace Pharmacy_Management_System.Repository
{
    public interface IDoctorRepository
    {
        void AddDoctor(Doctor doctor);
        
    }
}
