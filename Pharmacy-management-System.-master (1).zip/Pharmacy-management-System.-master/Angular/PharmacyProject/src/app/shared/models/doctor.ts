export class Doctor {
  DoctorId: string;
  DoctorName: string;
  Password: string;
  EmailId: string;
  Address: string;
  Contact: string;
}
