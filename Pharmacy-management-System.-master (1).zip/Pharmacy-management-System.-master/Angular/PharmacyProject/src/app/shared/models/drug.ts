export class Drug {
  drugId: number;
  drugName: string;
  drugPrice: number;
  drugQuantity: number;
  expDate: string;
  mfdDate: string;
  supplierId: number;
}
