export class Order {
  orderId: number;
  doctorId: string;
  drugId: number;
  drugsName: string;
  drugPrice: number;
  drugQuantity: number;
  pickupDate: string;
  totalAmount: number;
  isPicked: string;
}
