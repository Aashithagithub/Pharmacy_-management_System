export class Supplier {
  supplierId: number;
  supplierName: string;
  emailId: string;
  phoneNumber: string;
  drugAvailable: string;
}
