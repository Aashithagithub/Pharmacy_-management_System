export class Login {
  EmailId: string;
  Password: string;
}
